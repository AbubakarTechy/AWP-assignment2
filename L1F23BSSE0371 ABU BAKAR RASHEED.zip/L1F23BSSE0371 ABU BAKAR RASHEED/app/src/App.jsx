import { Routes, Route } from 'react-router-dom'
import Navbar from './Components/Navbar'
import Home from './Pages/Home'
import Services from './Pages/Services'
import AddService from './Pages/AddService'

function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/services" element={<Services />} />
        <Route path="/add" element={<AddService />} />
      </Routes>
    </>
  )
}

export default App