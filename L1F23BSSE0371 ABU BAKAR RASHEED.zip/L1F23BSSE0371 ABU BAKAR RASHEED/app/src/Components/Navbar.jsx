import { Link, useLocation } from 'react-router-dom'

const Navbar = () => {
  const location = useLocation()

  return (
    <nav className="bg-gradient-to-r from-blue-700 to-indigo-700 px-8 py-4 flex items-center justify-between shadow-lg">
      {/* Logo */}
      <div className="flex items-center gap-2">
        <span className="text-2xl">🏙️</span>
        <span className="text-white font-extrabold text-xl tracking-wide">ServiceApp</span>
      </div>

      {/* Links */}
      <div className="flex items-center gap-2">
        <Link
          to="/"
          className={`px-4 py-2 rounded-lg font-medium transition-all ${
            location.pathname === '/'
              ? 'bg-white text-blue-700'
              : 'text-white hover:bg-white/20'
          }`}
        >
           Home
        </Link>
        <Link
          to="/services"
          className={`px-4 py-2 rounded-lg font-medium transition-all ${
            location.pathname === '/services'
              ? 'bg-white text-blue-700'
              : 'text-white hover:bg-white/20'
          }`}
        >
           Services
        </Link>
        <Link
          to="/add"
          className="bg-white text-blue-700 px-5 py-2 rounded-lg font-bold hover:bg-blue-50 transition-all shadow-md"
        >
          Add Service
        </Link>
      </div>
    </nav>
  )
}

export default Navbar