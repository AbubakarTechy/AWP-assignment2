import { useState } from 'react'
import { useServices } from '../context/ServicesContext'
import ServiceCard from './ServiceCard'

const ServiceList = () => {
  const { services, handleDelete, loading, error } = useServices()
  const [search, setSearch] = useState('')

  const filtered = services.filter((service) =>
    service.name.toLowerCase().includes(search.toLowerCase())
  )

  if (loading) return (
    <div className="flex items-center justify-center py-20">
      <p className="text-xl text-blue-600 animate-pulse">Loading services...</p>
    </div>
  )

  if (error) return (
    <div className="flex items-center justify-center py-20">
      <p className="text-xl text-red-500">{error}</p>
    </div>
  )

  return (
    <div>
      <input
        type="text"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="Search services..."
        className="w-full p-3 rounded-lg border border-gray-300 mb-6 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
      />
      <p className="text-gray-500 mb-4">{filtered.length} services found</p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((service) => (
          <ServiceCard
            key={service.id}
            name={service.name}
            category={service.category}
            rating={service.rating}
            onDelete={() => handleDelete(service.id)}
          />
        ))}
      </div>
    </div>
  )
}

export default ServiceList