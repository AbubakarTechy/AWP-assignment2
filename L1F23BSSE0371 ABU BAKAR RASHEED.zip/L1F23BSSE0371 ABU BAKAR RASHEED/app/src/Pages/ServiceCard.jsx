const ServiceCard = ({ name, category, rating, onDelete }) => {
  return (
    <div className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow">
      <h3 className="text-xl font-bold text-gray-800 mb-2">{name}</h3>
      <p className="text-blue-600 font-medium mb-1">📂 {category}</p>
      <p className="text-yellow-500 font-medium">⭐ {rating} / 5</p>
      <button
        onClick={onDelete}
        className="mt-4 bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 w-full"
      >
        Delete
      </button>
    </div>
  )
}

export default ServiceCard