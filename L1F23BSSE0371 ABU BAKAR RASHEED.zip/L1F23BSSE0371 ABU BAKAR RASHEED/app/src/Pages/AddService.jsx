import { useState } from 'react'
import { useServices } from '../context/ServicesContext'

const AddService = () => {
  const { handleAdd } = useServices()
  const [name, setName] = useState('')
  const [category, setCategory] = useState('')
  const [rating, setRating] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    handleAdd({ id: Date.now(), name, category, rating: Number(rating) })
    setName('')
    setCategory('')
    setRating('')
  }

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Add New Service</h2>
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl shadow-md max-w-md">
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Service Name" className="w-full p-3 border border-gray-300 rounded-lg mb-4 focus:outline-none focus:ring-2 focus:ring-blue-400" />
        <input type="text" value={category} onChange={(e) => setCategory(e.target.value)} placeholder="Category" className="w-full p-3 border border-gray-300 rounded-lg mb-4 focus:outline-none focus:ring-2 focus:ring-blue-400" />
        <input type="number" value={rating} onChange={(e) => setRating(e.target.value)} placeholder="Rating (1-5)" min="1" max="5" className="w-full p-3 border border-gray-300 rounded-lg mb-4 focus:outline-none focus:ring-2 focus:ring-blue-400" />
        <button type="submit" className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 font-medium">Add Service</button>
      </form>
    </div>
  )
}

export default AddService