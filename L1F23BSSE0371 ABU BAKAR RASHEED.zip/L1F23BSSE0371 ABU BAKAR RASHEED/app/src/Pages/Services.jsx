import ServiceList from './ServiceList'

const Services = () => {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <div className="bg-blue-600 text-white text-center py-10">
        <h1 className="text-3xl font-bold">All Services</h1>
        <p className="text-blue-100 mt-2">Browse the complete list</p>
      </div>

      <div className="p-8 flex-grow">
        <ServiceList />
      </div>

      <footer className="bg-gray-800 text-white text-center py-6">
        <p className="text-gray-400 text-sm">© 2025 ServiceApp. All rights reserved.</p>
      </footer>
    </div>
  )
}

export default Services