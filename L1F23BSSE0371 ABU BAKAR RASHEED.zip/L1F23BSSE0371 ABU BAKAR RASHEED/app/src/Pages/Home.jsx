import { useState } from 'react'
import { Link } from 'react-router-dom'
import ServiceCard from './ServiceCard'
import { useServices } from '../context/ServicesContext'

const Home = () => {
  const { services, handleDelete, loading, error } = useServices()
  const [search, setSearch] = useState('')

  const filtered = services.filter((service) =>
    service.name.toLowerCase().includes(search.toLowerCase())
  )

  if (loading) return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <p className="text-xl text-blue-600 font-medium animate-pulse">Loading services...</p>
    </div>
  )

  if (error) return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <p className="text-xl text-red-500 font-medium">{error}</p>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">

      {/* Hero Section */}
      <div className="bg-gradient-to-br from-blue-700 to-indigo-800 text-white text-center py-16 px-4">
        <h1 className="text-5xl font-extrabold mb-3 tracking-tight">🏙️ Find Local Services</h1>
        <p className="text-blue-200 text-lg mb-8">Hospitals, Restaurants, Parks & more in your city</p>

        {/* Search Bar */}
        <div className="flex items-center max-w-lg mx-auto bg-white rounded-xl shadow-xl overflow-hidden">
          <span className="pl-4 text-gray-400 text-xl">🔍</span>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search hospitals, restaurants..."
            className="flex-1 p-4 text-gray-800 focus:outline-none"
          />
          <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-4 font-semibold transition-all">
            Search
          </button>
        </div>

        {/* Stats */}
        <div className="flex justify-center gap-8 mt-8 text-blue-100 text-sm">
          <span>🏥 Hospitals</span>
          <span>🍽️ Restaurants</span>
          <span>🌳 Parks</span>
        </div>
      </div>

      {/* Services Grid */}
      <div className="p-8 flex-grow">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Featured Services</h2>
          <span className="text-gray-500 text-sm">{filtered.length} services found</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.slice(0, 9).map((service) => (
            <ServiceCard
              key={service.id}
              name={service.name}
              category={service.category}
              rating={service.rating}
              onDelete={() => handleDelete(service.id)}
            />
          ))}
        </div>

        {/* Show More */}
        {filtered.length > 9 && (
          <div className="text-center mt-10">
            <Link
              to="/services"
              className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-10 py-4 rounded-xl hover:from-blue-700 hover:to-indigo-700 font-bold shadow-lg transition-all"
            >
              Show All {filtered.length} Services →
            </Link>
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 text-center">
        <p className="text-2xl font-bold mb-1">🏙️ ServiceApp</p>
        <p className="text-gray-400 text-sm">© Developed by Abu Bakar</p>
      </footer>

    </div>
  )
}

export default Home