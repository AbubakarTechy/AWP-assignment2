import { createContext, useContext, useState, useEffect } from 'react'
import axios from 'axios'

const ServicesContext = createContext()

export const ServicesProvider = ({ children }) => {
  const [services, setServices] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const query = `
      [out:json];
      (
        node["amenity"="hospital"](31.4,74.2,31.6,74.4);
        node["amenity"="restaurant"](31.4,74.2,31.6,74.4);
        node["amenity"="park"](31.4,74.2,31.6,74.4);
      );
      out;
    `
    axios.get('https://overpass-api.de/api/interpreter', {
      params: { data: query }
    })
    .then((response) => {
      const mapped = response.data.elements.map((item) => ({
        id: item.id,
        name: item.tags.name || 'Unknown',
        category: item.tags.amenity,
        rating: (Math.random() * 2 + 3).toFixed(1)
      }))
      setServices(mapped)
      setLoading(false)
    })
    .catch((err) => {
      setError('Failed to fetch services. Please try again.')
      setLoading(false)
    })
  }, [])

  const handleAdd = (newService) => {
    setServices([...services, newService])
  }

  const handleDelete = (id) => {
    setServices(services.filter((service) => service.id !== id))
  }

  return (
    <ServicesContext.Provider value={{ services, handleAdd, handleDelete, loading, error }}>
      {children}
    </ServicesContext.Provider>
  )
}

export const useServices = () => useContext(ServicesContext)