import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'
import {BrowserRouter} from 'react-router-dom'
import './index.css'
import { ServicesProvider } from './context/ServicesContext'


createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter>
       <ServicesProvider>   
            <App />
        </ServicesProvider>   

    </BrowserRouter>

   </StrictMode>,
)
